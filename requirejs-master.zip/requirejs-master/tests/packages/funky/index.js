define(['./lib/monkey'], function (monkey) {
    return {
        name: 'funky',
        monkeyName: monkey.name
    };
});
