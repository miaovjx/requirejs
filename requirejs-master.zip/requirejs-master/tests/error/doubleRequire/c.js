define(['myShim'], function (broken) {
  return { name: 'c' };
});
