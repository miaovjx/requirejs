define('application', ['person'], function(person) {
    return {
        name: 'application',
        person: person
    };
});
