define(function() {
  return {
    load: function(name, req, onload, config) {
      onload(name);
    }
  }
});
