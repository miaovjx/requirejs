define(function (require) {
    var a = require('a');
    return {
        name: 'c',
        aName: a.name
    };
});
