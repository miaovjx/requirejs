define(['i18n!nls/colors'], function (colors) {
   return colors.blue;
});
