define(["require", "exports", "module", "./b"], function(require, exports, module) {
exports.foo = require('./b').foo;

});
