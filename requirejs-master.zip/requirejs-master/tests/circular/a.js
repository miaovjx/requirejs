define(['b', 'exports'], function (b, exports) {
    exports.name = 'a';
    exports.b = b;
});
