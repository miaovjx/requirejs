define(['exports', 'viewport', 'helper'], function (exports, viewport, helper) {

    exports.name = 'main';
    exports.viewport = viewport;
    exports.helper = helper;
});
