define({
    name: 'foo2'
});
