define(function (require, exports, module) {
    return {
        food: module.config().id
    };
});

